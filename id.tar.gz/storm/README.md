# storm-kafka-twitter
Scan Twitter trending topics in a distributed environment using Apache Kafka and Storm.
